import { ep } from "../core/ApiEndpoint";

export const Upload = {
  Single: ep("POST", "upload"),
};
