import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
    SafeAreaView,
    View,
    StyleSheet,
    ScrollView,
    useWindowDimensions,
    Text,
    TouchableOpacity,
} from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useUIFactory } from "../ui/factory/useUIFactory";
import HeaderBar from "../components/common/HeaderBar.tsx";
import GradientButton from "../components/common/GradientButton";
import { RootStackParamList } from "../navigation/AppNavigator";
import MaskedView from "@react-native-masked-view/masked-view";
import Svg, { Path as SvgPath } from "react-native-svg";
import { Camera } from "react-native-vision-camera";
import { useFaceDetectionHandle, FaceDetectionStep } from "../utils/FaceDetectionHandle";
// === THÊM IMPORT CỦA SKIA ===
import {
    Canvas,
    Path as SkiaPath,
    Skia,
    LinearGradient, // Skia có component LinearGradient riêng
    vec,
    PathOp
} from "@shopify/react-native-skia";

import ImageResizer from 'react-native-image-resizer';
import { Image } from 'react-native';

type StepKey = FaceDetectionStep;
type StepDefinition = { key: StepKey; label: string };

type Props = NativeStackScreenProps<RootStackParamList, "PersonalInformationFaceDetection">;

export default function PersonalInformationFaceDetectionScreen({ navigation }: Props) {
    const { width } = useWindowDimensions();
    // === ĐỊNH NGHĨA KÍCH THƯỚC OVAL MONG MUỐN ===
    const OVAL_WIDTH = width * 0.8;
    const OVAL_HEIGHT = OVAL_WIDTH * (4.5 / 3);
    const STROKE_WIDTH = 12;

    const RING_GRADIENT = ["#2EF5D2", "#1E4DFF"];
    const BUTTON_GRADIENT = ["#BCD9FF", "#488EEB"];
    const BUTTON_RADIUS = 12;

    const { loading, theme, lang } = useUIFactory();
    const t = lang?.t;

    const steps = useMemo<StepDefinition[]>(
        () => [
            { key: "front", label: t?.("face_step_front") ?? "Đưa mặt thẳng vào khung" },
            { key: "left", label: t?.("face_step_left") ?? "Nghiêng mặt sang trái" },
            { key: "right", label: t?.("face_step_right") ?? "Nghiêng mặt sang phải" }
        ],
        [t]
    );

    const stepMap = useMemo(
        () => steps.reduce<Record<StepKey, StepDefinition>>((acc, s) => { acc[s.key] = s; return acc; }, {} as any),
        [steps]
    );

    const {
        cameraRef,
        device,
        hasPermission,
        permissionStatus,
        isCameraActive,
        isCameraReady,
        frameProcessor,
        handleFront,
        handleLeft,
        handleRight,
        refreshPermission,
    } = useFaceDetectionHandle();

    const permissionBlocked = permissionStatus === "denied" || permissionStatus === "restricted";
    const cameraStatusMessage = useMemo(() => {
        if (permissionBlocked) return "Allow camera access in settings to continue.";
        if (!hasPermission) return "Waiting for camera permission...";
        if (!device) return "No compatible camera found.";
        if (!isCameraReady) return "Preparing camera...";
        return "Camera is waking up...";
    }, [device, hasPermission, isCameraReady, permissionBlocked]);

    const [currentStep, setCurrentStep] = useState<StepKey>("front");
    const [flowAttempt, setFlowAttempt] = useState(0);
    const [flowState, setFlowState] = useState<"idle" | "running" | "error" | "done">("idle");
    const [flowError, setFlowError] = useState<string | null>(null);
    const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    const startFlow = useCallback(() => setFlowAttempt(prev => prev + 1), []);

    const cancelRetry = useCallback(() => {
        if (retryTimeoutRef.current) {
            clearTimeout(retryTimeoutRef.current);
            retryTimeoutRef.current = null;
        }
    }, []);

    const scheduleRetry = useCallback(
        (delay = 1600) => {
            if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
            retryTimeoutRef.current = setTimeout(() => {
                retryTimeoutRef.current = null;
                if (hasPermission && isCameraReady && device) {
                    startFlow();
                }
            }, delay);
        },
        [device, hasPermission, isCameraReady, startFlow]
    );

    useEffect(() => () => cancelRetry(), [cancelRetry]);

    const getErrorMessage = useCallback((reason?: string) => {
        switch (reason) {
            case "camera_not_ready":
                return lang?.t('face_camera_not_ready');
            case "face_not_front":
                return lang?.t('face_face_not_front');
            case "face_not_left":
                return lang?.t('face_face_not_left');
            case "face_not_right":
                return lang?.t('face_face_not_right');
            case "capture_failed":
                return lang?.t('face_capture_failed');
            default:
                return null;
        }
    }, []);

    const handleFlowFailure = useCallback(
        (reason?: string, step?: StepKey, shouldRetry = true) => {
            setFlowState("error");
            const fallbackLabel = step ? stepMap[step]?.label : null;
            setFlowError(getErrorMessage(reason) ?? fallbackLabel ?? null);
            if (shouldRetry) {
                scheduleRetry();
            }
        },
        [getErrorMessage, scheduleRetry, stepMap]
    );

    useEffect(() => {
        if (isCameraReady && hasPermission && device && flowAttempt === 0) {
            startFlow();
        }
    }, [device, flowAttempt, hasPermission, isCameraReady, startFlow]);

    const addFilePrefix = (u: string) =>
        /^((file|content|https?):)\/\//.test(u) ? u : `file://${u}`;

    async function rotateImage(uri: string, degrees = 270): Promise<string> {
        const normalized = addFilePrefix(uri);

        // Lấy kích thước gốc để không scale sai (fallback 1080x1080 nếu lỗi)
        const { width, height } = await new Promise<{ width: number; height: number }>(resolve => {
            Image.getSize(
                normalized,
                (w, h) => resolve({ width: w, height: h }),
                () => resolve({ width: 1080, height: 1080 })
            );
        });

        const out = await ImageResizer.createResizedImage(
            normalized,
            width,     // giữ đúng kích thước gốc
            height,    // giữ đúng kích thước gốc
            'JPEG',
            100,       // chất lượng
            degrees    // 90 / 180 / 270; 270 = xoay -90
        );
        return addFilePrefix(out.uri);
    }

    useEffect(() => {
        if (!flowAttempt || !isCameraReady || !hasPermission || !device) return;

        let cancelled = false;

        const runFlow = async () => {
            setFlowState("running");
            setFlowError(null);

            // 1) Front
            setCurrentStep("front");
            const frontRes = await handleFront();
            if (!frontRes?.ok) { handleFlowFailure(frontRes?.reason, "front", frontRes?.reason !== "camera_not_ready"); return; }
            setCapturedFaces(prev => ({ ...prev, front: frontRes.uri }));

            // 2) Left
            setCurrentStep("left");
            const leftRes = await handleLeft();
            if (!leftRes?.ok) { handleFlowFailure(leftRes?.reason, "left"); return; }
            setCapturedFaces(prev => ({ ...prev, left: leftRes.uri }));

            // 3) Right
            setCurrentStep("right");
            const rightRes = await handleRight();
            if (!rightRes?.ok) { handleFlowFailure(rightRes?.reason, "right"); return; }
            setCapturedFaces(prev => ({ ...prev, right: rightRes.uri }));

            // ✅ Dùng biến cục bộ, KHÔNG dùng state capturedFaces khi navigate
            if (!cancelled) {
                setFlowState("done");
                // ✅ XOAY 3 ẢNH — PHẢI await (dùng Promise.all cho nhanh)
                const [frontUri, leftUri, rightUri] = await Promise.all([
                    rotateImage(frontRes.uri, 270),
                    rotateImage(leftRes.uri, 270),
                    rotateImage(rightRes.uri, 270),
                ]);

                setTimeout(() => {
                    navigation.navigate("PersonalInformation", {
                        faces: {
                            image_left: leftUri,
                            image_front: frontUri,
                            image_right: rightUri,
                        },
                    });
                }, 500);
            }
        };

        runFlow();
        return () => {
            cancelled = true;
        };
    }, [
        flowAttempt,
        isCameraReady,
        hasPermission,
        device,
        handleFront,
        handleLeft,
        handleRight,
        handleFlowFailure,
        cancelRetry,
    ]);

    // === TẠO PATH CHO SKIA ===
    // 1. Path cho nền xám bên trong

    const { innerOvalPath, innerOvalSvgPath, outerOvalPath, dimOutsidePath } = useMemo(() => {
        const innerRect = Skia.XYWHRect(STROKE_WIDTH / 2, STROKE_WIDTH / 2, OVAL_WIDTH - STROKE_WIDTH, OVAL_HEIGHT - STROKE_WIDTH);
        const inner = Skia.Path.Make();
        inner.addOval(innerRect);

        const outerRect = Skia.XYWHRect(STROKE_WIDTH / 2, STROKE_WIDTH / 2, OVAL_WIDTH - STROKE_WIDTH, OVAL_HEIGHT - STROKE_WIDTH);
        const outer = Skia.Path.Make();
        outer.addOval(outerRect);

        // Lớp phủ tối = (hình chữ nhật bao ngoài) - (elip bên trong)
        const fullRect = Skia.Path.Make();
        fullRect.addRect(Skia.XYWHRect(0, 0, OVAL_WIDTH, OVAL_HEIGHT));

        const outside = fullRect.copy();
        outside.op(inner, PathOp.Difference);

        return {
            innerOvalPath: inner,
            innerOvalSvgPath: inner.toSVGString(),
            outerOvalPath: outer,
            dimOutsidePath: outside,
        };
    }, [OVAL_HEIGHT, OVAL_WIDTH, STROKE_WIDTH]);

    // =====================================
    const [capturedFaces, setCapturedFaces] = useState<{ front?: string; left?: string; right?: string }>({});

    if (loading || !theme || !lang) return null;
    const styles = makeStyles(theme);

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: theme.colors.background }}>
            <ScrollView>
                <HeaderBar
                    title={lang.t("face_detection_title")}
                    onBack={() => navigation?.goBack?.()}
                    extra={<View style={{ width: 34 }} />}
                />

                {/* Khung oval (THAY BẰNG SKIA CANVAS) */}
                <View style={styles.faceGuide}>
                    <View style={[styles.ovalWrapper, { width: OVAL_WIDTH, height: OVAL_HEIGHT }]}>
                        <MaskedView
                            style={StyleSheet.absoluteFillObject}
                            maskElement={
                                <Svg width={OVAL_WIDTH} height={OVAL_HEIGHT}>
                                    <SvgPath d={innerOvalSvgPath} fill="#fff" />
                                </Svg>
                            }
                        >
                            <View style={styles.cameraSurface}>
                                {device && hasPermission ? (
                                    <Camera
                                        ref={cameraRef}
                                        style={StyleSheet.absoluteFillObject}
                                        device={device}
                                        isActive={isCameraActive}
                                        photo={true}
                                        frameProcessor={frameProcessor}
                                    />
                                ) : (
                                    <View style={styles.cameraFallback}>
                                        <Text style={styles.cameraFallbackText}>{cameraStatusMessage}</Text>
                                        {!permissionBlocked && (
                                            <TouchableOpacity style={styles.cameraFallbackButton} onPress={refreshPermission}>
                                                <Text style={styles.cameraFallbackButtonText}>Enable camera</Text>
                                            </TouchableOpacity>
                                        )}
                                    </View>
                                )}
                            </View>
                        </MaskedView>

                        <Canvas style={[StyleSheet.absoluteFillObject]} pointerEvents="none">
                            <SkiaPath path={dimOutsidePath} style="fill" color={theme.colors.background} />
                            <SkiaPath path={outerOvalPath} style="stroke" strokeWidth={STROKE_WIDTH}>
                                <LinearGradient
                                    start={vec(OVAL_WIDTH * 0.1, 0)}
                                    end={vec(OVAL_WIDTH * 0.9, OVAL_HEIGHT)}
                                    colors={RING_GRADIENT}
                                />
                            </SkiaPath>
                        </Canvas>
                    </View>
                </View>
                {/* (Kết thúc khối Skia) */}

                {/* Nút hiển thị như LABEL (không bấm) */}
                {flowError ? (
                    <Text style={styles.statusText}>{flowError}</Text>
                ) : flowState === "running" ? (
                    <Text style={styles.statusText}>{lang.t('face_status_label')}</Text>
                ) : null}
                {flowState === "error" && (
                    <TouchableOpacity style={styles.retryLink} onPress={startFlow}>
                        <Text style={styles.retryLinkText}>{lang.t('face_retry_link')}</Text>
                    </TouchableOpacity>
                )}
                <View style={{ alignItems: "center", marginBottom: 50 }}>
                    <GradientButton
                        text={stepMap[currentStep].label}
                        onPress={() => {
                            if (flowState === "running") return;
                            if (!hasPermission) {
                                refreshPermission();
                                return;
                            }
                            if (device && isCameraReady) {
                                startFlow();
                            }
                        }}
                        colors={BUTTON_GRADIENT}
                        borderRadius={BUTTON_RADIUS}
                        textColor="#0B1A39"
                        style={{ width: "80%" }}
                    />
                </View>

            </ScrollView>
        </SafeAreaView>
    );
}

const makeStyles = (theme: any) =>
    StyleSheet.create({
        faceGuide: {
            marginTop: "20%",
            marginBottom: "10%",
            alignItems: "center", // Giữ lại để căn giữa Canvas
            justifyContent: "center",
            width: "100%",

            // Thêm shadow/elevation vào đây nếu bạn muốn
            shadowColor: "#1E4DFF",
            shadowOpacity: 0.15,
            shadowOffset: { width: 0, height: 4 },
            shadowRadius: 8,
            elevation: 2,
        },

        ovalWrapper: {
            position: "relative",
        },
        cameraSurface: {
            flex: 1,
            backgroundColor: "#0B1A39",
        },
        cameraFallback: {
            flex: 1,
            alignItems: "center",
            justifyContent: "center",
            paddingHorizontal: 24,
            backgroundColor: "#0B1A39",
            gap: 12,
        },
        cameraFallbackText: {
            color: "#ffffff",
            textAlign: "center",
            fontSize: 14,
            lineHeight: 20,
        },
        cameraFallbackButton: {
            paddingHorizontal: 20,
            paddingVertical: 8,
            borderRadius: 18,
            borderWidth: 1,
            borderColor: "#ffffff",
        },
        cameraFallbackButtonText: {
            color: "#ffffff",
            fontWeight: "600",
        },
        statusText: {
            marginTop: 16,
            paddingHorizontal: 24,
            textAlign: "center",
            fontSize: 13,
            color: "#6B7AA1",
        },
        retryLink: {
            marginTop: 8,
            paddingHorizontal: 16,
            paddingVertical: 6,
        },
        retryLinkText: {
            color: "#1E4DFF",
            fontWeight: "700",
            alignSelf: "center"
        },
    });
